import React from 'react';
import { Wrench } from 'lucide-react';
import LeadForm from './components/LeadForm';

function App() {
  return (
    <div className="min-h-screen bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center space-y-6">
          <h1 className="text-4xl font-extrabold text-[#ffbd59] sm:text-5xl sm:tracking-tight lg:text-6xl">
            Welcome to OBD2AI's Engine Bay Analyzer!
          </h1>
          <p className="max-w-2xl mx-auto text-xl text-zinc-400 leading-relaxed">
            Using advanced AI technology, we can analyze your engine bay and provide instant insights about your vehicle's condition.
            Simply share your details below and upload a clear photo of your engine bay.
          </p>
        </div>
        
        <div className="mt-16">
          <LeadForm />
        </div>
      </div>
    </div>
  );
}

export default App;
