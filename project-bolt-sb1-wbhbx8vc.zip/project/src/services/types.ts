export interface BaseAnalysisResult {
  condition: string;
  observations: string[];
  recommendations: string[];
}

export interface EngineAnalysisResult extends BaseAnalysisResult {
  type: 'engine';
}

export interface SoundAnalysisResult extends BaseAnalysisResult {
  type: 'sound';
  soundProfile: {
    idleQuality: string;
    noiseLevel: string;
    unusualSounds: string[];
    explanations: Record<string, string>; // Technical term explanations
  };
}

export type AnalysisResult = EngineAnalysisResult | SoundAnalysisResult;