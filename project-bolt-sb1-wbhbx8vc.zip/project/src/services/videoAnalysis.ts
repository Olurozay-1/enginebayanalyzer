import { GoogleGenerativeAI } from "@google/generative-ai";
import { SoundAnalysisResult } from "./types";

const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
if (!apiKey) {
  throw new Error('VITE_GEMINI_API_KEY environment variable is not set');
}
const genAI = new GoogleGenerativeAI(apiKey);
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

const SYSTEM_PROMPT = `You are an expert automotive technician analyzing engine sound from videos. For each video:
1. Assess the overall engine sound quality
2. Identify any unusual noises or patterns
3. Note potential issues based on the sounds
4. Provide maintenance recommendations
5. Include explanations for any technical terms used

Keep responses accessible to non-experts but include detailed insights.
Format your response in JSON with the following structure:
{
  "type": "sound",
  "condition": "string describing overall engine condition based on sound",
  "observations": ["array of key sound-related observations"],
  "recommendations": ["array of maintenance recommendations"],
  "soundProfile": {
    "idleQuality": "description of how smoothly the engine idles",
    "noiseLevel": "description of overall noise level",
    "unusualSounds": ["array of any concerning sounds detected"],
    "explanations": {
      "technical_term": "simple explanation",
      "another_term": "its explanation"
    }
  }
}`;

export async function analyzeSoundProfile(videoFile: File): Promise<SoundAnalysisResult> {
  try {
    const videoData = await fileToGenerativePart(videoFile);
    
    if (!videoData.inlineData.data) {
      throw new Error('Failed to process video file');
    }

    const result = await model.generateContent([
      { text: SYSTEM_PROMPT },
      videoData,
      { text: "Analyze this engine sound video and provide insights in the specified JSON format." }
    ]);

    const response = await result.response;
    const text = await response.text();
    
    try {
      const cleanJson = text.replace(/```json\n|\n```/g, '').trim();
      const analysisResult = JSON.parse(cleanJson) as SoundAnalysisResult;
      return analysisResult;
    } catch (parseError) {
      console.error('Failed to parse API response:', text);
      throw new Error('Invalid response format from API');
    }    
  } catch (error) {
    console.error('Error analyzing engine sound:', error);
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to analyze engine sound. Please try again.');
  }
}

async function fileToGenerativePart(file: File) {
  const base64Data = await fileToBase64(file);
  return {
    inlineData: {
      data: base64Data,
      mimeType: file.type
    }
  };
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        const base64 = reader.result.split(',')[1];
        resolve(base64);
      } else {
        reject(new Error('Failed to convert file to base64'));
      }
    };
    reader.onerror = error => reject(error);
  });
}