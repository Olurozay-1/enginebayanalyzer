import { GoogleGenerativeAI } from "@google/generative-ai";

// Initialize the Gemini API with your API key
const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
if (!apiKey) {
  throw new Error('VITE_GEMINI_API_KEY environment variable is not set');
}
const genAI = new GoogleGenerativeAI(apiKey);

// Get the model
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

export interface AnalysisResult {
  condition: string;
  observations: string[];
  recommendations: string[];
}

const SYSTEM_PROMPT = `You are an expert automotive technician analyzing engine bay images. For each image:
1. Assess the overall condition
2. Identify visible components and their condition
3. Note any obvious issues or areas of concern
4. Provide maintenance recommendations

Keep responses concise and use non-technical language when possible.
Format your response in JSON with the following structure:
{
  "condition": "string describing overall condition",
  "observations": ["array of key observations"],
  "recommendations": ["array of maintenance recommendations"]
}`;

export async function analyzeEngineBay(imageFile: File): Promise<AnalysisResult> {
  try {
    // Convert the image file to base64
    const imageData = await fileToGenerativePart(imageFile);
    
    if (!imageData.inlineData.data) {
      throw new Error('Failed to process image file');
    }

    // Generate content with the image and prompt
    const result = await model.generateContent([
      { text: SYSTEM_PROMPT },
      imageData,
      { text: "Analyze this engine bay image and provide insights in the specified JSON format." }
    ]);

    const response = await result.response;
    const text = await response.text();
    
    // Clean and parse the JSON response
    try {
      // Remove markdown code block markers if present
      const cleanJson = text.replace(/```json\n|\n```/g, '').trim();
      const analysisResult = JSON.parse(cleanJson) as AnalysisResult;
      return analysisResult;
    } catch (parseError) {
      console.error('Failed to parse API response:', text);
      throw new Error('Invalid response format from API');
    }    
  } catch (error) {
    console.error('Error analyzing engine bay:', error);
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to analyze engine bay image. Please try again.');
  }
}

// Helper function to convert File to GenerativePart
async function fileToGenerativePart(file: File) {
  const base64Data = await fileToBase64(file);
  return {
    inlineData: {
      data: base64Data,
      mimeType: file.type
    }
  };
}

// Helper function to convert File to base64
function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        // Remove the data URL prefix (e.g., "data:image/jpeg;base64,")
        const base64 = reader.result.split(',')[1];
        resolve(base64);
      } else {
        reject(new Error('Failed to convert file to base64'));
      }
    };
    reader.onerror = error => reject(error);
  });
}