import React, { useState } from 'react';
import { Upload, Video, Loader2 } from 'lucide-react';
import { analyzeEngineBay } from '../services/gemini';
import { analyzeSoundProfile } from '../services/videoAnalysis';
import { AnalysisResult } from '../services/types';
import AnalysisResults from './AnalysisResults';

interface FormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  image: File | null;
  video: File | null;
}

export default function LeadForm() {
  const [formData, setFormData] = useState<FormData>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    image: null,
    video: null,
  });
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResults, setAnalysisResults] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const imageInputRef = React.useRef<HTMLInputElement>(null);
  const videoInputRef = React.useRef<HTMLInputElement>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.image && !formData.video) {
      setError('Please upload at least one file (photo or video)');
      return;
    }

    setIsAnalyzing(true);
    setError(null);

    try {
      let results: AnalysisResult;
      
      if (formData.video) {
        results = await analyzeSoundProfile(formData.video);
      } else {
        results = {
          type: 'engine',
          ...(await analyzeEngineBay(formData.image!))
        };
      }
      
      setAnalysisResults(results);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      setFormData({ ...formData, image: e.target.files[0] });
      setError(null);
    }
  };
  
  const handleVideoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      const file = e.target.files[0];
      if (file.size > 50 * 1024 * 1024) { // 50MB limit
        setError('Video file size must be under 50MB');
        return;
      }
      setFormData({ ...formData, video: file });
      setError(null);
    }
  };

  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    
    const files = e.dataTransfer.files;
    if (files?.[0]?.type.startsWith('image/')) {
      setFormData({ ...formData, image: files[0] });
      setError(null);
    } else if (files?.[0]?.type.startsWith('video/')) {
      if (files[0].size > 50 * 1024 * 1024) {
        setError('Video file size must be under 50MB');
        return;
      }
      setFormData({ ...formData, video: files[0] });
      setError(null);
    }
  };

  const handleImageUploadClick = () => {
    imageInputRef.current?.click();
  };

  const handleVideoUploadClick = () => {
    videoInputRef.current?.click();
  };

  // If we have analysis results, only show them
  if (analysisResults) {
    return (
      <div className="w-full max-w-4xl mx-auto">
        <AnalysisResults results={analysisResults} />
      </div>
    );
  }

  // Otherwise show the form
  return (
    <div className="w-full max-w-4xl mx-auto">
      <form onSubmit={handleSubmit} className="space-y-10 backdrop-blur-sm bg-zinc-900/50 rounded-2xl p-8 shadow-xl border border-zinc-800">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label>First Name*</label>
            <input
              type="text"
              required
              placeholder="Please enter your first name"
              onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
            />
          </div>
          <div>
            <label>Last Name*</label>
            <input
              type="text"
              required
              placeholder="Please enter your last name"
              onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label>Email*</label>
            <input
              type="email"
              required
              placeholder="Enter your email address"
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            />
          </div>
          <div>
            <label>Phone*</label>
            <input
              type="tel"
              required
              placeholder="Enter your phone number"
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            />
          </div>
        </div>

        <div className="mt-4">
          <label>Upload Engine Bay Photo & Video*</label>
          <p className="text-sm text-zinc-400 mb-2">
            Please provide a clear photo of your engine bay and a 10-second video of your engine running.
            The video helps us analyze engine sounds for a more complete diagnosis.
          </p>
          <div
            className="grid grid-cols-1 md:grid-cols-2 gap-4"
          >
            <div
              className={`upload-area ${isDragging ? 'border-[#ffbd59]' : ''}`}
              onDragEnter={handleDragEnter}
              onDragLeave={handleDragLeave}
              onDragOver={handleDragOver}
              onDrop={handleDrop}
              onClick={handleImageUploadClick}
            >
              <div className="space-y-3 text-center">
                <Upload className="mx-auto h-12 w-12 text-[#ffbd59]" />
                <div className="flex text-sm text-gray-600 justify-center">
                  <label className="relative cursor-pointer rounded-md font-medium text-[#ffbd59] hover:text-[#ffd08f]">
                    <span>Upload Photo</span>
                    <input
                      ref={imageInputRef}
                      type="file"
                      className="sr-only"
                      accept="image/*"
                      onChange={handleImageChange}
                    />
                  </label>
                </div>
                {formData.image ? (
                  <p className="text-sm text-[#ffbd59]">Selected: {formData.image.name}</p>
                ) : (
                  <p className="text-xs text-zinc-400">Clear, well-lit engine bay photo</p>
                )}
              </div>
            </div>
            
            <div
              className={`upload-area ${isDragging ? 'border-[#ffbd59]' : ''}`}
              onDragEnter={handleDragEnter}
              onDragLeave={handleDragLeave}
              onDragOver={handleDragOver}
              onDrop={handleDrop}
              onClick={handleVideoUploadClick}
            >
              <div className="space-y-3 text-center">
                <Video className="mx-auto h-12 w-12 text-[#ffbd59]" />
                <div className="flex text-sm text-gray-600 justify-center">
                  <label className="relative cursor-pointer rounded-md font-medium text-[#ffbd59] hover:text-[#ffd08f]">
                    <span>Upload Video</span>
                    <input
                      ref={videoInputRef}
                      type="file"
                      className="sr-only"
                      accept="video/*"
                      onChange={handleVideoChange}
                    />
                  </label>
                </div>
                {formData.video ? (
                  <p className="text-sm text-[#ffbd59]">Selected: {formData.video.name}</p>
                ) : (
                  <p className="text-xs text-zinc-400">10-second video of running engine</p>
                )}
              </div>
            </div>
          </div>
        </div>

        {error && (
          <div className="mt-4 p-4 bg-red-900/50 border-l-4 border-red-500 rounded-r-xl">
            <p className="text-sm text-red-200">{error}</p>
          </div>
        )}

        <button
          type="submit"
          disabled={isAnalyzing}
          className="w-full flex justify-center py-4 px-6 border border-transparent rounded-xl text-base font-semibold text-black bg-[#ffbd59] hover:bg-[#ffd08f] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#ffbd59] disabled:opacity-50 transition-all duration-200 shadow-lg shadow-[#ffbd59]/20"
        >
          {isAnalyzing ? (
            <>
              <Loader2 className="animate-spin -ml-1 mr-3 h-5 w-5 text-black" />
              Analyzing...
            </>
          ) : (
            'Analyze Engine'
          )}
        </button>
      </form>
    </div>
  );
}