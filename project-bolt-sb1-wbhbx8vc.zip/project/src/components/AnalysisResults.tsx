import { AlertCircle, Car, History } from 'lucide-react';
import { AnalysisResult } from '../services/types';

interface Props {
  results: AnalysisResult;
}

export default function AnalysisResults({ results }: Props) {
  const isSoundAnalysis = results.type === 'sound';

  return (
    <div className="mt-8 space-y-6">
      <div className="bg-zinc-900/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg border border-zinc-800">
        <h3 className="text-lg font-medium text-white">Analysis Results</h3>
        <div className="mt-4 space-y-4">
          <div>
            <h4 className="font-medium text-zinc-300">General Condition:</h4>
            <p className="mt-1 text-zinc-400">{results.condition}</p>
          </div>
          
          {isSoundAnalysis && (
            <div>
              <h4 className="font-medium text-zinc-300">Sound Profile:</h4>
              <div className="mt-2 space-y-2 text-zinc-400">
                <p><span className="text-zinc-300">Idle Quality:</span> {results.soundProfile.idleQuality}</p>
                <p><span className="text-zinc-300">Noise Level:</span> {results.soundProfile.noiseLevel}</p>
                {results.soundProfile.unusualSounds.length > 0 && (
                  <div>
                    <p className="text-zinc-300">Unusual Sounds Detected:</p>
                    <ul className="list-disc list-inside pl-4">
                      {results.soundProfile.unusualSounds.map((sound, i) => (
                        <li key={i}>{sound}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          )}

          <div>
            <h4 className="font-medium text-zinc-300">Key Observations:</h4>
            <ul className="mt-1 list-disc list-inside text-zinc-400">
              {results.observations.map((obs, i) => (
                <li key={i}>{obs}</li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-medium text-zinc-300">Recommended Actions:</h4>
            <ul className="mt-1 list-disc list-inside text-zinc-400">
              {results.recommendations.map((rec, i) => (
                <li key={i}>{rec}</li>
              ))}
            </ul>
          </div>

          {isSoundAnalysis && Object.keys(results.soundProfile.explanations).length > 0 && (
            <div>
              <h4 className="font-medium text-zinc-300">Technical Terms Explained:</h4>
              <dl className="mt-2 space-y-2">
                {Object.entries(results.soundProfile.explanations).map(([term, explanation]) => (
                  <div key={term}>
                    <dt className="text-[#ffbd59]">{term}</dt>
                    <dd className="text-zinc-400 pl-4">{explanation}</dd>
                  </div>
                ))}
              </dl>
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-zinc-900/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg border border-zinc-800">
          <div className="flex items-center">
            <Car className="h-8 w-8 text-[#ffbd59]" />
            <h3 className="ml-3 text-lg font-medium text-white">OBD2AI Scanner</h3>
          </div>
          <p className="mt-4 text-zinc-400">Get real-time engine diagnostics, decode error codes instantly, and monitor vehicle performance.</p>
          <p className="mt-2 text-lg font-semibold text-[#ffbd59]">£25-£30</p>
          <button className="mt-4 w-full inline-flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-black bg-[#ffbd59] hover:bg-[#ffd08f]">
            Learn More
          </button>
        </div>

        <div className="bg-zinc-900/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg border border-zinc-800">
          <div className="flex items-center">
            <History className="h-8 w-8 text-[#ffbd59]" />
            <h3 className="ml-3 text-lg font-medium text-white">Full Car History Check</h3>
          </div>
          <p className="mt-4 text-zinc-400">Verify mileage accuracy, check accident history, and confirm service records.</p>
          <p className="mt-2 text-lg font-semibold text-[#ffbd59]">£20-£25</p>
          <button className="mt-4 w-full inline-flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-black bg-[#ffbd59] hover:bg-[#ffd08f]">
            Check Now
          </button>
        </div>
      </div>

      <div className="bg-zinc-900/80 backdrop-blur-sm border-l-4 border-[#ffbd59] p-6 rounded-r-2xl">
        <div className="flex">
          <AlertCircle className="h-5 w-5 text-[#ffbd59]" />
          <p className="ml-3 text-sm text-zinc-300">
            Thank you for using OBD2AI's Engine Bay Analyzer! We'll send your detailed report to your email address.
          </p>
        </div>
      </div>
    </div>
  );
}